/******************************************
* File: main.cpp                          *
* Author: Amber Goodman                   *
* Date: 04/2025                           *
* Purpose: main driver file for Project 3 *
*******************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <list>

#include "Person.hpp"

using namespace std;

list <Person> merge(list<Person> A, list<Person> B, string test)
{
  list<Person> sorted;
  while (!A.empty() && !B.empty())
  {
    if (test == "test1")
    {
      if (A.front().test1() < B.front().test1())
      {
        sorted.push_back(A.front()); 
        A.pop_front();
      }
       else 
      {
        sorted.push_back(B.front());
        B.pop_front();
      }
    }
    else if (test == "test2")
    {
      if (A.front().test2() < B.front().test2())
      {
        sorted.push_back(A.front()); 
        A.pop_front();
      }
      else 
      {
        sorted.push_back(B.front());
        B.pop_front();
      }
    }
  }
    
  while (!A.empty())
  {
    sorted.push_back(B.front());
    B.pop_front();
  }
  
  return sorted;

}

void mergeSort(list <Person> &val, string test)
{
  if (val.size() <=1)
    return;
    
  int j = val.size() / 2;
  list<Person> left;
  list<Person> right;
  
  // left
  for (int i=0; i<j; i++)
  {
    left.push_back(val.front());
    val.pop_front();
  }
  
  // right
  while(!val.empty())
  {
    right.push_back(val.front());
    val.pop_front();
  }
  
  mergeSort(left, test);
  mergeSort(right, test);
  
  merge(left, right, test);
}

int main(int argc, char *argv[])
{
  Person person;
  Person person2;
   
  list <Person> list;

  ifstream file(argv[1]);
  
  while (file.peek() != EOF)    // Bug 
  { 
    file >> person.name();
    file >> person.test1();
    file >> person.test2();
    
    // insert into list of Person nodes
    list.push_back(person);
   
    cout << person.name() << " " << person.test1() << " " << person.test2() << endl;
  }
  
  file.close();
  
  double diff = 100.0;
  double newdiff;
    
  if (string(argv[2]) == "1") // greedy?
  {
    // sort 
    string test1 = "test1";
    mergeSort(list, test1);
  
    // compare only test 1
    for (unsigned int j = 0; j < list.size(); j++)
    { 
      newdiff = list.front()-> person.test1() - list.next() -> person2.test1(); // difference of two scores
      list.pop_front();
      if (newdiff < diff)
        diff = newdiff;
    }
    cout << person.name() << " " << person2.name() << " " << diff << endl;
  }
  
  else if (string(argv[2]) == "2")  // greedy?
  {
    // sort
    string test2 = "test2";
    mergeSort(list, test2);
    //compare only test 2
     for (unsigned int j = 0; j < list.size(); j++)
    { 
      newdiff = list.front()-> person.test2() - list.next() -> person2.test2(); // difference of two scores
        list.pop_front();
        if (newdiff < diff)
          diff = newdiff;
    }
    cout << person.name() << " " << person2.name() << " " << diff << endl;
  }
  
  else (string(argv[2]) == "b"); // divide and conquer
  {
    // compare both quiz scores
    list <Person> list1;
    list <Person> list2;
    
    while (int n/2: list)           // put half of original list in list1
    {
      list1.push_back(list.front());
      list.pop_front();
    }
    
    while(!list.empty())           // put the rest of list in list2
    {
      list2.push_back(list.front());
      list.pop_front();
    }
    
    
      
    
  }
  

  return 0;
}
